# CountyStat_Airflow

Python package used by CountyStat for Airflow operations:
* DevTest
* Slack Alert

[Package building reference](https://packaging.python.org/en/latest/tutorials/packaging-projects/)

## DevTest



## Slack Alert

